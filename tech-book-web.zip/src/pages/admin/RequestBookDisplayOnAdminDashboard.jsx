import AdminLayout from "../../Layout/AdminLayout";

const RequestBookDisplayOnAdminDashboard = () => {
  return (
    <AdminLayout>
      <div>RequestBookDisplayOnAdminDashboard</div>
    </AdminLayout>
  );
};

export default RequestBookDisplayOnAdminDashboard;
