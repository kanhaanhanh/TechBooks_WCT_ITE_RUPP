export default {
    // ... other configuration options
  
    output: {
      // ... other output options
      manualChunks: {
        // Define manual chunks if needed
      },
      chunkSizeWarningLimit: 2000, // Set an appropriate limit for your project
    },
  };